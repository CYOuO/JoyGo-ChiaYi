import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:hugeicons/hugeicons.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../theme/app_theme.dart';
import '../theme/fabric_textures.dart';
import '../services/static_data_cache.dart';
import 'settings_screen.dart';
import 'expense_screen.dart';
// TranslatedText imported below with translation_service
import '../widgets/spot_save_button.dart';
import 'search_screen.dart';
import 'notifications_screen.dart';
import 'news_transport_screens.dart';
import 'camera_screen.dart';
import 'weather_screen.dart';
import 'news_transport_screens.dart' show TransportScreen, NewsScreen;
import 'map_screen.dart' show MapScreen;
import '../services/rail_service.dart'; // 🌟 引入統一的 Service
import '../utils/html_utils.dart';
import '../utils/dept_style.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../providers/app_settings_provider.dart';
import '../widgets/common_widgets.dart' show SectionHeader, SpotRatingSection, TapFeedback, WashiTapeDivider, PolaroidCard, TranslatedText;
import '../services/translation_service.dart';
import 'stamp_screen.dart';


Map<String, dynamic> _govItemToJson(_GovItem n) => {
  'title': n.title, 'date': n.date, 'location': n.location,
  'summary': n.summary, 'url': n.url, 'imageUrl': n.imageUrl,
  'isEvent': n.isEvent,
};
_GovItem _govItemFromJson(Map<String, dynamic> m) => _GovItem(
  title:    m['title']    as String? ?? '',
  date:     m['date']     as String? ?? '',
  location: m['location'] as String?,
  summary:  m['summary']  as String?,
  url:      m['url']      as String?,
  imageUrl: m['imageUrl'] as String?,
  isEvent:  m['isEvent']  as bool?   ?? false,
);

const _kCardBg = Color(0xFFFFFFFF);
const _kCardRadius    = 22.0;
const _kCardShadow    = [
  BoxShadow(
    color: Color(0x14C09060),
    blurRadius: 20,
    offset: Offset(0, 6),
    spreadRadius: -2,
  ),
];

/// 浮動白色卡片容器 — 參考「奶酪單詞」風格
Widget _warmSection({
  required Widget child,
  EdgeInsetsGeometry margin = const EdgeInsets.fromLTRB(16, 0, 16, 0),
  EdgeInsetsGeometry padding = const EdgeInsets.all(16),
}) {
  return Container(
    margin: margin,
    padding: padding,
    decoration: BoxDecoration(
      color: _kCardBg,
      borderRadius: BorderRadius.circular(_kCardRadius),
      boxShadow: _kCardShadow,
    ),
    child: child,
  );
}

PageRoute<void> _goRoute(Widget screen) => PageRouteBuilder<void>(
  pageBuilder: (_, __, ___) => screen,
  transitionsBuilder: (_, anim, __, child) => FadeTransition(
    opacity: CurvedAnimation(parent: anim, curve: Curves.easeOut),
    child: SlideTransition(
      position: Tween<Offset>(begin: const Offset(0, 0.05), end: Offset.zero)
          .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
      child: child,
    ),
  ),
  transitionDuration: const Duration(milliseconds: 270),
  reverseTransitionDuration: const Duration(milliseconds: 210),
);

class HomeScreen extends StatefulWidget {
  final VoidCallback? onOpenDrawer;
  final void Function(int)? onSwitchTab;
  final VoidCallback? onGoToTripCalendar;

  const HomeScreen({super.key, this.onOpenDrawer, this.onSwitchTab, this.onGoToTripCalendar});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _WaveClipper extends CustomClipper<Path> {
  final double animValue;
  const _WaveClipper(this.animValue);

  @override
  Path getClip(Size s) {
    final base = s.height - 48.0;
    final p = Path()..lineTo(0, base + 8);
    p.cubicTo(
      s.width * 0.25, base - 14,
      s.width * 0.75, base + 22,
      s.width,        base + 4,
    );
    p.lineTo(s.width, 0);
    p.lineTo(0, 0);
    p.close();
    return p;
  }

  @override
  bool shouldReclip(_WaveClipper old) => old.animValue != animValue;
}

class _WaveLinePainter extends CustomPainter {
  final Color color;
  const _WaveLinePainter({required this.color});

  @override
  void paint(Canvas canvas, Size s) {
    final base = s.height - 72.0;
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.8
      ..strokeCap = StrokeCap.round;

    final path = Path()..moveTo(0, base + 6);
    path.cubicTo(
      s.width * 0.30, base - 10,
      s.width * 0.70, base + 18,
      s.width,        base + 2,
    );
    canvas.drawPath(path, paint);

    final base2 = s.height - 90.0;
    final paint2 = Paint()
      ..color = color.withValues(alpha: color.a * 0.5)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0;
    final path2 = Path()..moveTo(0, base2 + 4);
    path2.cubicTo(
      s.width * 0.35, base2 - 8,
      s.width * 0.65, base2 + 14,
      s.width,        base2,
    );
    canvas.drawPath(path2, paint2);
  }

  @override
  bool shouldRepaint(covariant _WaveLinePainter old) => old.color != color;
}

class _HomeScreenState extends State<HomeScreen> {
  final PageController _bannerController = PageController();
  int _currentBanner = 0;
  int _unreadCount   = 0;
  Timer? _autoScrollTimer;

  List<_GovItem> _newsItems = [];
  bool _newsLoading = true;
  bool _newsError   = false;
  Position? _myPos;

  List<_RestaurantItem> _restaurants = [];
  bool _restaurantsLoading = true;
  final PageController _restaurantPageCtrl = PageController(viewportFraction: 0.82);

  List<_NearbySpotItem> _nearbySpots = [];
  bool _nearbyLoading = true;
  String _nearbyFilter = '全部';
  static const _kNearbyFilters = ['全部', 'TDX景點', '好店', '寵物友善', '飲料店'];

  static const _kNewsCacheKey   = 'home_news_v1';
  static const _kNewsCacheTsKey = 'home_news_ts_v1';
  static const _kNewsCacheTTLMs = 30 * 60 * 1000;

  static const _kEventsUrl = 'https://data.chiayi.gov.tw/opendata/api/getResource?oid=33c3225e-f786-4eaf-8b9c-774cc39c72e0&rid=a809167f-bba6-475d-9dfe-33b4ea7749f6';
  static const _kNewsUrl = 'https://data.chiayi.gov.tw/opendata/api/getResource?oid=6dcaf207-e99b-4846-bd72-c334ce0d4b59&rid=87d4b27c-07c3-4546-815d-1e733dfd9497';

  // 🌟 宣告變數：接收首頁即時天氣數據
  Map<String, dynamic>? _todayLiveWeather;

  // 交通動態即時資料
  String _busLine = '--', _busInfo = '--';
  String _ybStation = '--', _ybInfo = '--';
  String _traInfo = '--:--';

  @override
  void initState() {
    super.initState();
    _fetchLocation();
    _fetchNews();
    _fetchRestaurants();
    _fetchNearbySpots();
    _fetchHomeLiveWeather();
    _fetchHomeTransport();
    _listenUnreadNotifs();
  }

  void _listenUnreadNotifs() {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) { setState(() => _unreadCount = 0); return; }
    FirebaseFirestore.instance
        .collection('users').doc(uid)
        .collection('notifications')
        .where('isRead', isEqualTo: false)
        .snapshots()
        .listen((snap) {
      if (mounted) setState(() => _unreadCount = snap.docs.length);
    });
  }

  // 🌟 新增：實時調用 Service 獲取今日天氣快照
  Future<void> _fetchHomeLiveWeather() async {
    try {
      final weatherList = await RailService.getWeather('Chiayi');
      if (weatherList.isNotEmpty && mounted) {
        setState(() {
          _todayLiveWeather = weatherList.first;
        });
      }
    } catch (e) {
      debugPrint('首頁快照天氣獲取失敗: $e');
    }
  }

  Future<void> _fetchHomeTransport() async {
    try {
      // 公車：抓中山幹線第一個即將到站
      final busRes = await RailService.getBusDynamic('Chiayi', '中山幹線');
      final busData = (busRes['data'] as List? ?? []).cast<Map<String, dynamic>>();
      if (busData.isNotEmpty) {
        final active = busData.where((s) => (s['StopStatus'] as int? ?? 0) == 0 && s['EstimateTime'] != null).toList()
          ..sort((a, b) => (a['EstimateTime'] as int).compareTo(b['EstimateTime'] as int));
        if (active.isNotEmpty) {
          final m = (active.first['EstimateTime'] as int) ~/ 60;
          final stop = active.first['StopName'];
          final stopName = (stop is Map) ? (stop['Zh_tw']?.toString() ?? '') : (stop?.toString() ?? '');
          if (mounted) setState(() { _busLine = stopName.length > 4 ? stopName.substring(0, 4) : stopName; _busInfo = m <= 1 ? '即將進站' : '$m 分鐘'; });
        }
      }
    } catch (_) {}
    try {
      // YouBike：火車站站點
      final ybRes = await RailService.getYoubikeData();
      final ybData = (ybRes['data'] as List? ?? []).cast<Map<String, dynamic>>();
      final station = ybData.firstWhere(
        (s) => (s['station_name'] ?? '').toString().contains('火車站'),
        orElse: () => ybData.isNotEmpty ? ybData.first : {},
      );
      if (station.isNotEmpty) {
        final gen = station['GeneralBikes'] as int? ?? 0;
        final elec = station['ElectricBikes'] as int? ?? 0;
        var name = (station['station_name'] ?? '').toString().replaceAll(RegExp(r'YouBike\d+\.0_'), '');
        if (name.length > 4) name = name.substring(0, 4);
        if (mounted) setState(() { _ybStation = name; _ybInfo = '${gen + elec} 輛可借'; });
      }
    } catch (_) {}
    try {
      // 台鐵：嘉義→台北 最近一班
      final n = DateTime.now().toUtc().add(const Duration(hours: 8));
      final today = '${n.year}-${n.month.toString().padLeft(2, '0')}-${n.day.toString().padLeft(2, '0')}';
      final nowTime = '${n.hour.toString().padLeft(2, '0')}:${n.minute.toString().padLeft(2, '0')}';
      final traRes = await RailService.queryTra(origin: '嘉義', dest: '台北', trainDate: today);
      final trains = (traRes['data'] as List? ?? []).cast<Map<String, dynamic>>();
      final upcoming = trains.where((t) => (t['departure_time']?.toString() ?? '').compareTo(nowTime) >= 0).toList();
      if (upcoming.isNotEmpty) {
        if (mounted) setState(() => _traInfo = upcoming.first['departure_time']?.toString().substring(0, 5) ?? '--:--');
      }
    } catch (_) {}
  }

  Future<void> _fetchLocation() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) return;
      LocationPermission perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) return;
      final pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.low).timeout(const Duration(seconds: 8));
      if (!mounted) return;
      _myPos = pos;
      if (_restaurants.isNotEmpty) _sortRestaurantsByProximity();
      if (_nearbySpots.isNotEmpty) _sortNearbyByProximity();
    } catch (_) {}
  }

  // 附近判斷半徑（公尺）
  static const _kRestaurantRadius = 5000.0;  // 5km
  static const _kSpotRadius       = 8000.0;  // 8km
  static const _kMinResults       = 4;       // 至少顯示幾筆（不足時不過濾）

  AppL10n get _l10n => context.read<AppSettingsProvider>().l10n;
  String get _restaurantSectionTitle => _myPos != null ? _l10n.homeNearbyTurkeyRice : _l10n.homeFeaturedTurkeyRice;
  String get _spotSectionTitle       => _myPos != null ? _l10n.homeNearbySpots      : _l10n.homeHotFood;

  void _sortRestaurantsByProximity() {
    if (_myPos == null) return;
    final lat = _myPos!.latitude, lng = _myPos!.longitude;
    final sorted = [..._restaurants];
    sorted.sort((a, b) {
      if (a.lat == null || a.lng == null) return 1;
      if (b.lat == null || b.lng == null) return -1;
      return Geolocator.distanceBetween(lat, lng, a.lat!, a.lng!).compareTo(Geolocator.distanceBetween(lat, lng, b.lat!, b.lng!));
    });
    // 過濾 5km 內，至少保留 _kMinResults 筆
    final nearby = sorted.where((r) => r.lat != null && r.lng != null && Geolocator.distanceBetween(lat, lng, r.lat!, r.lng!) <= _kRestaurantRadius).toList();
    if (mounted) setState(() => _restaurants = nearby.length >= _kMinResults ? nearby : sorted);
  }

  void _sortNearbyByProximity() {
    if (_myPos == null) return;
    final lat = _myPos!.latitude, lng = _myPos!.longitude;
    final sorted = [..._nearbySpots];
    sorted.sort((a, b) {
      if (a.lat == null || a.lng == null) return 1;
      if (b.lat == null || b.lng == null) return -1;
      return Geolocator.distanceBetween(lat, lng, a.lat!, a.lng!).compareTo(Geolocator.distanceBetween(lat, lng, b.lat!, b.lng!));
    });
    // 過濾 8km 內，至少保留 _kMinResults 筆
    final nearby = sorted.where((s) => s.lat != null && s.lng != null && Geolocator.distanceBetween(lat, lng, s.lat!, s.lng!) <= _kSpotRadius).toList();
    if (mounted) setState(() => _nearbySpots = nearby.length >= _kMinResults ? nearby : sorted);
  }

  @override
  void dispose() {
    _bannerController.dispose();
    _restaurantPageCtrl.dispose();
    _autoScrollTimer?.cancel();
    super.dispose();
  }

  void _startAutoScroll() {
    _autoScrollTimer?.cancel();
    if (_newsItems.isEmpty) return;
    _autoScrollTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (!mounted || !_bannerController.hasClients) return;
      final next = (_currentBanner + 1) % _newsItems.length;
      _bannerController.animateToPage(next, duration: const Duration(milliseconds: 450), curve: Curves.easeInOut);
    });
  }

  Future<void> _fetchNews() async {
    if (!mounted) return;
    final prefs  = await SharedPreferences.getInstance();
    final ts     = prefs.getInt(_kNewsCacheTsKey) ?? 0;
    final cached = prefs.getString(_kNewsCacheKey);
    final age    = DateTime.now().millisecondsSinceEpoch - ts;

    if (cached != null && cached.isNotEmpty) {
      try {
        final list = (jsonDecode(cached) as List)
            .map((m) => _govItemFromJson(m as Map<String, dynamic>))
            .where((item) => item.title.isNotEmpty && item.title != '無標題')
            .toList();
        if (mounted && list.isNotEmpty) {
          setState(() { _newsItems = list; _newsLoading = false; _newsError = false; });
          _startAutoScroll();
          if (age < _kNewsCacheTTLMs) return;
        }
      } catch (_) {}
    }

    if (mounted && _newsItems.isEmpty) {
      setState(() { _newsLoading = true; _newsError = false; });
    }

    try {
      final results = await Future.wait([
        _fetchNewsOne(_kEventsUrl, isEvent: true),
        _fetchNewsOne(_kNewsUrl,   isEvent: false),
      ]).timeout(const Duration(seconds: 12));
      final combined = [...results[0], ...results[1]]..sort((a, b) => b.date.compareTo(a.date));
      if (!mounted) return;
      final fresh = combined.where((item) => item.title.isNotEmpty && item.title != '無標題').take(5).toList();
      setState(() { _newsItems = fresh; _newsLoading = false; _newsError = false; });
      _startAutoScroll();
      try {
        await prefs.setString(_kNewsCacheKey, jsonEncode(fresh.map(_govItemToJson).toList()));
        await prefs.setInt(_kNewsCacheTsKey, DateTime.now().millisecondsSinceEpoch);
      } catch (_) {}
    } catch (_) {
      if (mounted && _newsItems.isEmpty) {
        setState(() { _newsError = true; _newsLoading = false; });
      }
    }
  }

  Future<void> _fetchRestaurants() async {
    final cached = await StaticDataCache.load('restaurants');
    if (cached.isNotEmpty) {
      final list = cached.map(_restaurantFromDoc).where((r) => r.name.isNotEmpty).toList();
      if (mounted) setState(() { _restaurants = list; _restaurantsLoading = false; });
    }

    final stale = await StaticDataCache.isStale('restaurants');
    if (!stale && cached.isNotEmpty) return;

    if (cached.isEmpty && mounted) setState(() => _restaurantsLoading = true);
    final fresh = await StaticDataCache.refresh('restaurants');
    if (fresh.isEmpty) {
      if (mounted) setState(() => _restaurantsLoading = false);
      return;
    }
    var list = fresh.map(_restaurantFromDoc).where((r) => r.name.isNotEmpty).toList();
    if (_myPos != null) _sortListByProximity(list);
    if (mounted) { setState(() { _restaurants = list; _restaurantsLoading = false; }); if (_myPos != null) _sortRestaurantsByProximity(); }
  }

  void _sortListByProximity(List<_RestaurantItem> list) {
    if (_myPos == null) return;
    final lat = _myPos!.latitude, lng = _myPos!.longitude;
    list.sort((a, b) {
      if (a.lat == null || a.lng == null) return 1;
      if (b.lat == null || b.lng == null) return -1;
      return Geolocator.distanceBetween(lat, lng, a.lat!, a.lng!).compareTo(Geolocator.distanceBetween(lat, lng, b.lat!, b.lng!));
    });
  }

  _RestaurantItem _restaurantFromDoc(Map<String, dynamic> d) {
    final images = (d['images'] as List?)?.whereType<String>().toList() ?? [];
    double? lat, lng;
    final loc = d['location'];
    if (loc is GeoPoint && loc.latitude > 21 && loc.latitude < 26) {
      lat = loc.latitude; lng = loc.longitude;
    } else {
      for (final k in ['lat','latitude','緯度']) {
        final v = d[k]; if (v is num) { lat = v.toDouble(); break; }
      }
      for (final k in ['lng','longitude','經度']) {
        final v = d[k]; if (v is num) { lng = v.toDouble(); break; }
      }
    }
    return _RestaurantItem(
      id:        d['__id']?.toString() ?? '',
      name:      d['name']?.toString() ?? '',
      rating:    (d['rating'] as num?)?.toDouble() ?? 0,
      tags:      (d['tags'] as List?)?.whereType<String>().toList() ?? [],
      imageUrl:  images.isNotEmpty ? images.first : '',
      allImages: images,
      address:   d['address']?.toString() ?? '',
      shortDesc: d['shortDesc']?.toString() ?? '',
      price:     d['price']?.toString() ?? '',
      openTime:  d['time']?.toString() ?? '',
      lat: lat, lng: lng,
    );
  }

  static const _nameKeys = ['name','Name','店家名稱','業者名稱','名稱','店名','公共場所名稱','場所名稱','地點','停車場名稱','單位名稱','中文單位名稱'];
  static const _addrKeys = ['address','Address','地址','加油站地址','營業地址','設置地點','場所地址','路段'];
  static const _imgKeys = ['imageUrl','image','Pic','pic','圖片','thumbnail'];
  static const _descKeys = [
    'description','Description','descriptionDetail','DescriptionDetail',
    'Content','content','remarks','Remarks','Info','info',
    '簡介','產品特色','場所描述','特色介紹','備註','內容','活動說明',
  ];
  static const _latKeys = ['緯度','緯度坐標','地點LAT','Latitude','POINT_Y','lat'];
  static const _lngKeys = ['經度','經度坐標','地點LNG','Longitude','POINT_X','lng'];

  Future<void> _fetchNearbySpots() async {
    const cols = {
      'tdx_spots':            'TDX景點',
      'good_shops':           '好店',
      'pet_friendly_shops':   '寵物友善',
      'excellent_drink_shops':'飲料店',
    };

    final cachedLists = await Future.wait(cols.entries.map((e) => _loadNearbyCache(e.key, e.value)));
    final cachedAll = cachedLists.expand((x) => x).toList()..shuffle();
    if (cachedAll.isNotEmpty && mounted) {
      setState(() { _nearbySpots = cachedAll; _nearbyLoading = false; });
    }

    final staleCheck = await Future.wait(cols.keys.map(StaticDataCache.isStale));
    final anyStale = staleCheck.any((s) => s);
    if (!anyStale && cachedAll.isNotEmpty) return;

    if (cachedAll.isEmpty && mounted) setState(() => _nearbyLoading = true);

    final freshLists = await Future.wait(cols.entries.map((e) => _refreshNearby(e.key, e.value)));
    final freshAll = freshLists.expand((x) => x).toList()..shuffle();
    if (freshAll.isNotEmpty && mounted) {
      setState(() { _nearbySpots = freshAll; _nearbyLoading = false; });
      if (_myPos != null) _sortNearbyByProximity();
    } else if (mounted) {
      setState(() => _nearbyLoading = false);
    }
  }

  Future<List<_NearbySpotItem>> _loadNearbyCache(String col, String cat) async {
    final docs = await StaticDataCache.load(col);
    return docs.map((d) => _nearbyFromDoc(d, cat)).whereType<_NearbySpotItem>().toList();
  }

  Future<List<_NearbySpotItem>> _refreshNearby(String col, String cat) async {
    final docs = await StaticDataCache.refresh(col);
    return docs.map((d) => _nearbyFromDoc(d, cat)).whereType<_NearbySpotItem>().toList();
  }

  _NearbySpotItem? _nearbyFromDoc(Map<String, dynamic> d, String cat) {
    final id = d['__id']?.toString() ?? '';
    String name = '';
    for (final k in _nameKeys) {
      final v = d[k]?.toString() ?? '';
      if (v.isNotEmpty) { name = v; break; }
    }
    if (name.isEmpty) return null;
    String address = '';
    for (final k in _addrKeys) {
      final v = d[k]?.toString() ?? '';
      if (v.isNotEmpty) { address = v; break; }
    }
    String imageUrl = '';
    for (final k in _imgKeys) {
      final v = d[k];
      if (v is String && v.isNotEmpty) { imageUrl = v; break; }
      if (v is List && v.isNotEmpty) { imageUrl = v.first.toString(); break; }
    }
    String desc = '';
    for (final k in _descKeys) {
      final v = d[k]?.toString().trim() ?? '';
      if (v.length > 5) { desc = v; break; }
    }
    double? lat, lng;
    final loc = d['location'];
    if (loc is GeoPoint && loc.latitude > 21 && loc.latitude < 26 && loc.longitude > 119 && loc.longitude < 123) {
      lat = loc.latitude; lng = loc.longitude;
    } else {
      double? toNum(dynamic v) {
        if (v is double) return v;
        if (v is int)    return v.toDouble();
        if (v is String) return double.tryParse(v.trim());
        return null;
      }
      for (final k in _latKeys) {
        final n = toNum(d[k]);
        if (n != null && n > 21 && n < 26) { lat = n; break; }
      }
      for (final k in _lngKeys) {
        final n = toNum(d[k]);
        if (n != null && n > 119 && n < 123) { lng = n; break; }
      }
    }
    return _NearbySpotItem(id: id, name: name, category: cat, address: address, imageUrl: imageUrl, description: desc, lat: lat, lng: lng);
  }

  Future<List<_GovItem>> _fetchNewsOne(String url, {required bool isEvent}) async {
    try {
      final res = await http.get(Uri.parse(url), headers: {'Accept': 'application/json'});
      if (res.statusCode != 200) return [];
      final data = jsonDecode(res.body);
      List<dynamic> list;
      if (data is List) { list = data; } 
      else if (data is Map && data['result'] is List) { list = data['result'] as List; } 
      else if (data is Map && data['records'] is List) { list = data['records'] as List; } 
      else { list = []; }
      return list.whereType<Map>().map((m) {
        final raw   = Map<String, dynamic>.from(m);
        final title = _pickField(raw, ['title', '標題','活動名稱','名稱','Title']) ?? '無標題';
        final dateStr = isEvent ? _pickField(raw, ['ActiveStart','ActiveEnd','發布日期']) : _pickField(raw, ['PostDate','發布日期','建立時間']);
        final sum  = _pickField(raw, ['Content', '內容','摘要','描述','活動說明']);
        final postUnit = _pickField(raw, ['PostUnit','發布單位']);
        final imgUrl   = _pickField(raw, ['Pic','Thumbnail']);
        final link     = _pickField(raw, ['Source','連結','url']);
        return _GovItem(title: title, date: _shortDateStr(dateStr ?? ''), location: postUnit, summary: sum, url: link, imageUrl: imgUrl, isEvent: isEvent);
      }).toList();
    } catch (_) { return []; }
  }

  static String? _pickField(Map<String, dynamic> m, List<String> keys) {
    for (final k in keys) {
      final v = m[k];
      if (v != null && v.toString().trim().isNotEmpty) return v.toString().trim();
    }
    return null;
  }

  static String _shortDateStr(String s) {
    if (s.isEmpty) return '';
    final m = RegExp(r'(\d{4})[/\-](\d{1,2})[/\-](\d{1,2})').firstMatch(s);
    if (m != null) return '${m.group(1)}/${m.group(2)!.padLeft(2,'0')}/${m.group(3)!.padLeft(2,'0')}';
    return s.length > 10 ? s.substring(0, 10) : s;
  }

  void _goSearch() => Navigator.push(context, _goRoute(const SearchScreen()));
  void _goNotifications() => Navigator.push(context, _goRoute(const NotificationsScreen())).then((_) => setState(() => _unreadCount = 0));

  @override
  Widget build(BuildContext context) {
    final primary = context.appPrimary;
    final dark    = context.appPrimaryDark;
    final light   = Color.lerp(primary, Colors.white, 0.38) ?? primary;
    final bg = Theme.of(context).scaffoldBackgroundColor;
    
    return Scaffold(
      backgroundColor: bg,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 295,
            floating: false,
            pinned: true,
            backgroundColor: bg,
            elevation: 0,
            scrolledUnderElevation: 0,
            leading: null,
            automaticallyImplyLeading: false,
            actions: [
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 10, 8, 10),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    GestureDetector(
                      onTap: _goNotifications,
                      child: Container(
                        width: 38,
                        decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.55), borderRadius: BorderRadius.circular(12)),
                        child: const Center(child: HugeIcon(icon: HugeIcons.strokeRoundedNotification01, color: AppColors.textPrimary, size: 20)),
                      ),
                    ),
                    if (_unreadCount > 0) const Positioned(right: 0, top: 0, child: _PulsingDot()),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 10, 16, 10),
                child: GestureDetector(
                  onTap: () => Navigator.push(context, _goRoute(const SettingsScreen())),
                  child: Container(
                    width: 38,
                    decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.55), borderRadius: BorderRadius.circular(12)),
                    child: const Center(child: HugeIcon(icon: HugeIcons.strokeRoundedSettings01, color: AppColors.textPrimary, size: 20)),
                  ),
                ),
              ),
            ],
            flexibleSpace: FlexibleSpaceBar(
              background: ClipPath(
                clipper: const _WaveClipper(0.35),
                child: Container(
                  decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [light, primary, dark])),
                  child: Stack(
                    children: [
                      Positioned.fill(child: CustomPaint(painter: _WaveLinePainter(color: Colors.white.withValues(alpha: 0.22)))),
                      _StaticCircle(right: -40, top: -30, size: 190, alpha: 0.10),
                      _AnimatedCircle(right: 30, top: 28,  size: 75,  alpha: 0.07, duration: const Duration(seconds: 4), scaleTo: 1.18),
                      _AnimatedCircle(left: -25, bottom: 55, size: 120, alpha: 0.09, duration: const Duration(seconds: 5), scaleTo: 1.12, reverse: true),
                      _AnimatedCircle(left: 60,  bottom: 30, size: 50,  alpha: 0.06, duration: const Duration(seconds: 3), scaleTo: 1.25),
                      SafeArea(
                        bottom: false,
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(24, 0, 24, 90),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.end,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Stack(
                                clipBehavior: Clip.none,
                                children: [
                                  RichText(
                                    text: TextSpan(
                                      children: [
                                        const TextSpan(text: '去嘉義找', style: TextStyle(fontSize: 31, fontWeight: FontWeight.w900, color: Colors.white, height: 1.1, letterSpacing: 2.0)),
                                        TextSpan(text: 'Joy', style: GoogleFonts.pacifico(fontSize: 36, color: Colors.white, height: 1.1)),
                                      ],
                                    ),
                                  ),
                                  Positioned(
                                    right: -28, top: -12,
                                    child: CustomPaint(size: const Size(30, 28), painter: _JoyStrokesPainter(color: Colors.white.withValues(alpha: 0.75))),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 6),
                              // 🌟 完美修正：首頁氣象頂部同步改為對接數據層快照
                              GestureDetector(
                                onTap: () => Navigator.push(context, _goRoute(const WeatherScreen())),
                                child: Row(
                                  children: [
                                    Text(_todayLiveWeather?['icon'] ?? '⛅', style: const TextStyle(fontSize: 15)),
                                    const SizedBox(width: 5),
                                    Text('${_todayLiveWeather?['high'] ?? 32}°', style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w300, height: 1.0)),
                                    const SizedBox(width: 5),
                                    Text(_todayLiveWeather?['desc'] ?? '多雲時晴', style: TextStyle(color: Colors.white.withValues(alpha: 0.78), fontSize: 13, fontWeight: FontWeight.w500)),
                                    const SizedBox(width: 10),
                                    Container(width: 1, height: 11, color: Colors.white.withValues(alpha: 0.30)),
                                    const SizedBox(width: 10),
                                    _wInfoInline('☔', '${_todayLiveWeather?['rain'] ?? 20}%'),
                                    const SizedBox(width: 8),
                                    _wInfoInline('💧', '${_todayLiveWeather?['humid'] ?? 75}%'),
                                    const SizedBox(width: 8),
                                    _wInfoInline('💨', '${_todayLiveWeather?['wind'] ?? 12}km/h'),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 14),
                              GestureDetector(
                                onTap: _goSearch,
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(30),
                                  child: BackdropFilter(
                                    filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
                                      decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.22), borderRadius: BorderRadius.circular(30), border: Border.all(color: Colors.white.withValues(alpha: 0.35), width: 1.2)),
                                      child: Row(children: [
                                        HugeIcon(icon: HugeIcons.strokeRoundedSearch01, color: Colors.white.withValues(alpha: 0.85), size: 18),
                                        const SizedBox(width: 10),
                                        Text(context.watch<AppSettingsProvider>().l10n.homeSearchHint, style: TextStyle(color: Colors.white.withValues(alpha: 0.80), fontSize: 14, fontWeight: FontWeight.w500)),
                                      ]),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildQuickAccessGrid(),
                const WashiTapeDivider(),
                _buildTransportSection(),
                const WashiTapeDivider(color: Color(0x18E8A87C)),
                _buildNewsBanner(),
                const WashiTapeDivider(color: Color(0x18B08BD4)),
                _buildNearbyChickenRice(),
                const WashiTapeDivider(color: Color(0x1885B79D)),
                _buildNearbySpots(),
                const SizedBox(height: 100),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _wInfoInline(String icon, String v) => Row(children: [
    Text(icon, style: const TextStyle(fontSize: 10)),
    const SizedBox(width: 2),
    Text(v, style: TextStyle(color: Colors.white.withValues(alpha: 0.88), fontSize: 10, fontWeight: FontWeight.w600)),
  ]);

  Widget _quickRow(List<_QuickItem> rowItems, {int baseIndex = 0}) {
    return Row(
      children: rowItems.asMap().entries.map((e) {
        final isLast = e.key == rowItems.length - 1;
        final delay = (baseIndex + e.key) * 55;
        return Expanded(child: Container(
          margin: isLast ? EdgeInsets.zero : const EdgeInsets.only(right: 10),
          child: _BounceQuickButton(item: e.value)
            .animate()
            .fadeIn(delay: delay.ms, duration: 320.ms)
            .slideY(begin: 0.18, end: 0, delay: delay.ms, duration: 320.ms, curve: Curves.easeOutCubic),
        ));
      }).toList(),
    );
  }

  Widget _buildQuickAccessGrid() {
    final l10n = context.watch<AppSettingsProvider>().l10n;
    final items = [
      _QuickItem(HugeIcons.strokeRoundedLocation06, l10n.homeMapExplore,   const Color(0xFFE6F0E6), () => widget.onSwitchTab?.call(2)),
      _QuickItem(HugeIcons.strokeRoundedCalendar03, l10n.homeTripPlan,     const Color(0xFFF5EFE6), () => widget.onSwitchTab?.call(1)),
      _QuickItem(HugeIcons.strokeRoundedWallet01,   l10n.homeExpenseSplit, const Color(0xFFEDF5ED), () => Navigator.push(context, _goRoute(const ExpenseScreen()))),
      _QuickItem(HugeIcons.strokeRoundedUserGroup,  l10n.homeCommunityNav, const Color(0xFFEBEFF2), () => widget.onSwitchTab?.call(3)),
      _QuickItem(HugeIcons.strokeRoundedTicket01,   l10n.homeEventCal,     const Color(0xFFF0EBF5), () => widget.onGoToTripCalendar?.call()),
      _QuickItem(HugeIcons.strokeRoundedBus01,      l10n.homeTransport,    const Color(0xFFE8F0F5), () => Navigator.push(context, _goRoute(TransportScreen(onSwitchTab: (idx) => widget.onSwitchTab?.call(idx == 1 ? 2 : idx))))),
      _QuickItem(HugeIcons.strokeRoundedStar,       l10n.homeStamps,       const Color(0xFFF5F0E8), () => Navigator.push(context, _goRoute(const StampScreen()))),
      _QuickItem(HugeIcons.strokeRoundedCamera01,   l10n.homeCamera,       const Color(0xFFF0EDF5), () => Navigator.push(context, _goRoute(const CameraScreen()))),
    ];
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      child: _warmSection(
        margin: EdgeInsets.zero,
        padding: const EdgeInsets.fromLTRB(14, 16, 14, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(padding: const EdgeInsets.only(left: 2, bottom: 14), child: SectionHeader(title: l10n.homeQuickNav)),
            _quickRow(items.sublist(0, 4), baseIndex: 0),
            const SizedBox(height: 10),
            _quickRow(items.sublist(4, 8), baseIndex: 4),
          ],
        ),
      ),
    );
  }

  Widget _buildTransportSection() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 0),
      child: _warmSection(
        margin: EdgeInsets.zero,
        padding: const EdgeInsets.fromLTRB(14, 16, 14, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(padding: const EdgeInsets.only(left: 2, bottom: 14), child: SectionHeader(title: context.watch<AppSettingsProvider>().l10n.homeTransport, actionText: context.watch<AppSettingsProvider>().l10n.more, onAction: () => Navigator.push(context, _goRoute(const TransportScreen())))),
            Row(
              children: [
                Expanded(child: _transportCard(Icons.directions_bus_rounded, '中山幹線', _busLine, _busInfo, const Color(0xFFC4856A), 0)),
                const SizedBox(width: 10),
                Expanded(child: _transportCard(Icons.pedal_bike_rounded, 'YouBike', _ybStation, _ybInfo, const Color(0xFF5B8A5F), 1)),
                const SizedBox(width: 10),
                Expanded(child: _transportCard(Icons.train_rounded, '台鐵', '嘉→台北', _traInfo, const Color(0xFF88B8C8), 2)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _transportCard(IconData icon, String type, String line, String info, Color color, int tabIdx) {
    return TapFeedback(
      onTap: () {
        if (tabIdx == 1) {
          // YouBike → 跳到地圖頁並顯示 YouBike 站牌
          MapScreen.focusNotifier.value = (lat: 23.4780, lng: 120.4407, catKey: MapScreen.catKeyYouBike);
          widget.onSwitchTab?.call(2);
        } else {
          Navigator.push(context, _goRoute(TransportScreen(initialTab: tabIdx)));
        }
      },
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: color.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(18), border: Border.all(color: color.withValues(alpha: 0.18))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, size: 20, color: color),
          const SizedBox(height: 4),
          Text(type, style: TextStyle(fontSize: 11, color: color, fontWeight: FontWeight.w700)),
          Text(line, style: const TextStyle(fontSize: 10, color: AppColors.textSecondary)),
          const SizedBox(height: 4),
          Text(info, style: const TextStyle(fontSize: 11, color: AppColors.textPrimary, fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text(context.read<AppSettingsProvider>().l10n.homeViewMore, style: TextStyle(fontSize: 9, color: color.withValues(alpha: 0.7), fontWeight: FontWeight.w600)),
        ]),
      ),
    );
  }

  Widget _buildNewsBanner() {
    final primary = context.appPrimary;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(padding: const EdgeInsets.fromLTRB(20, 20, 20, 12), child: SectionHeader(title: context.watch<AppSettingsProvider>().l10n.homeLatestNews, actionText: _newsError ? context.read<AppSettingsProvider>().l10n.retry : context.read<AppSettingsProvider>().l10n.all, onAction: _newsError ? _fetchNews : () => Navigator.push(context, _goRoute(const NewsScreen())))),
        if (_newsLoading) SizedBox(height: 100, child: Center(child: CircularProgressIndicator(color: primary, strokeWidth: 2.5))),
        if (!_newsLoading && (_newsError || _newsItems.isEmpty))
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: GestureDetector(
              onTap: _newsError ? _fetchNews : null,
              child: Container(
                width: double.infinity, padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), boxShadow: _kCardShadow),
                child: Row(children: [
                  const Icon(Icons.inbox_rounded, size: 26, color: AppColors.textHint),
                  const SizedBox(width: 12),
                  Expanded(child: Text(_newsError ? context.read<AppSettingsProvider>().l10n.homeNewsLoadFail : context.read<AppSettingsProvider>().l10n.homeNoNews, style: const TextStyle(color: AppColors.textHint, fontSize: 13))),
                  if (_newsError) Icon(Icons.refresh_rounded, color: primary, size: 20),
                ]),
              ),
            ),
          ),
        if (!_newsLoading && !_newsError && _newsItems.isNotEmpty) ...[
          SizedBox(
            height: 134,
            child: PageView.builder(
              controller: _bannerController,
              onPageChanged: (i) => setState(() => _currentBanner = i),
              itemCount: _newsItems.length,
              itemBuilder: (_, index) {
                final item = _newsItems[index];
                final (catColor, catIconData) = deptColorIcon(item.location, item.isEvent);
                final catLabel = item.isEvent ? context.read<AppSettingsProvider>().l10n.homeNewsEventLabel : context.read<AppSettingsProvider>().l10n.homeNewsNewsLabel;
                final subtitle = cleanHtml(item.summary ?? item.location ?? '');
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: TapFeedback(
                    onTap: () => _showNewsDetail(item),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), boxShadow: _kCardShadow),
                      child: Row(children: [
                        Container(width: 44, height: 44, decoration: BoxDecoration(color: catColor.withValues(alpha: 0.10), borderRadius: BorderRadius.circular(12)), child: Center(child: Icon(item.isEvent ? Icons.event_rounded : Icons.article_outlined, size: 22, color: catColor))),
                        const SizedBox(width: 12),
                        Expanded(child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Row(children: [
                              Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2), decoration: BoxDecoration(color: catColor.withValues(alpha: 0.10), borderRadius: BorderRadius.circular(6)), child: Text(catLabel, style: TextStyle(color: catColor, fontSize: 10, fontWeight: FontWeight.w700))),
                              const Spacer(),
                              Text(item.date, style: const TextStyle(fontSize: 10, color: AppColors.textHint)),
                            ]),
                            const SizedBox(height: 6),
                            Text(item.title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: AppColors.textPrimary, height: 1.3), maxLines: 2, overflow: TextOverflow.ellipsis),
                            const SizedBox(height: 3),
                            Row(children: [
                              if (subtitle.isNotEmpty) Expanded(child: Text(subtitle, style: const TextStyle(fontSize: 11, color: AppColors.textHint, height: 1.2), maxLines: 1, overflow: TextOverflow.ellipsis)) else const Spacer(),
                              const SizedBox(width: 6),
                              Text(context.read<AppSettingsProvider>().l10n.homeReadFull, style: TextStyle(fontSize: 10, color: catColor, fontWeight: FontWeight.w600)),
                              Icon(Icons.arrow_forward_ios_rounded, size: 8, color: catColor),
                            ]),
                          ],
                        )),
                      ]),
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(_newsItems.length, (i) => AnimatedContainer(duration: const Duration(milliseconds: 280), margin: const EdgeInsets.symmetric(horizontal: 3), width: i == _currentBanner ? 18 : 6, height: 6, decoration: BoxDecoration(borderRadius: BorderRadius.circular(3), color: i == _currentBanner ? primary : AppColors.textHint.withValues(alpha: 0.25)))),
          ),
        ],

        const SizedBox(height: 24),
      ],
    );
  }


  void _showNewsDetail(_GovItem item) {
    final catColor = item.isEvent ? const Color(0xFF00838F) : const Color(0xFF1565C0);
    final cleanedSummary = cleanHtml(item.summary);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.75, maxChildSize: 0.95,
        builder: (ctx, scroll) => Container(
          decoration: const BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
          child: ListView(
            controller: scroll, padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
            children: [
              Center(child: Container(width: 36, height: 4, margin: const EdgeInsets.only(bottom: 16), decoration: BoxDecoration(color: AppColors.divider, borderRadius: BorderRadius.circular(2)))),
              Row(children: [
                Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: catColor.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(6)), child: Text(item.isEvent ? context.read<AppSettingsProvider>().l10n.newsTabEvent : context.read<AppSettingsProvider>().l10n.newsTabNews, style: TextStyle(color: catColor, fontSize: 12, fontWeight: FontWeight.w600))),
                const Spacer(),
                if (item.date.isNotEmpty) Text(item.date, style: const TextStyle(color: AppColors.textHint, fontSize: 12)),
              ]),
              const SizedBox(height: 10),
              TranslatedText(text: item.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.textPrimary, height: 1.4), domain: TranslationDomain.news),
              if (item.location != null && item.location!.isNotEmpty) ...[
                const SizedBox(height: 6),
                Row(children: [const Icon(Icons.business_rounded, size: 13, color: AppColors.textHint), const SizedBox(width: 4), Expanded(child: Text(item.location!, style: const TextStyle(color: AppColors.textHint, fontSize: 12)))],),
              ],
              const Divider(height: 24),
              if (cleanedSummary.isNotEmpty) TranslatedText(text: cleanedSummary, style: const TextStyle(fontSize: 15, color: AppColors.textSecondary, height: 1.85), domain: TranslationDomain.news),
              const SizedBox(height: 20),
              if (item.url != null && item.url!.isNotEmpty) ...[
                Row(children: [
                  Expanded(child: ElevatedButton.icon(onPressed: () async { try { final raw = item.url!.trim(); final uri = Uri.parse(raw.startsWith('http') ? raw : 'https://$raw'); await launchUrl(uri, mode: LaunchMode.externalApplication); } catch (_) { if (context.mounted) { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(context.read<AppSettingsProvider>().l10n.newsCannotOpen), behavior: SnackBarBehavior.floating)); } } }, icon: const Icon(Icons.open_in_new_rounded, size: 16), label: Text(context.read<AppSettingsProvider>().l10n.newsOpenOriginal))),
                  const SizedBox(width: 10),
                  OutlinedButton.icon(onPressed: () { Clipboard.setData(ClipboardData(text: item.url!)); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(context.read<AppSettingsProvider>().l10n.newsCopied), duration: const Duration(seconds: 2), behavior: SnackBarBehavior.floating)); }, icon: const Icon(Icons.copy_rounded, size: 16), label: Text(context.read<AppSettingsProvider>().l10n.newsCopyLink)),
                ]),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNearbyChickenRice() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(padding: const EdgeInsets.fromLTRB(20, 24, 20, 12), child: SectionHeader(title: _restaurantSectionTitle, actionText: '查看地圖', onAction: () => widget.onSwitchTab?.call(2))),
        SizedBox(
          height: 210,
          child: _restaurantsLoading
              ? ListView.builder(scrollDirection: Axis.horizontal, padding: const EdgeInsets.fromLTRB(16, 4, 16, 4), itemCount: 4, itemBuilder: (_, __) => _restaurantShimmer())
              : _restaurants.isEmpty
                  ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [const Icon(Icons.restaurant_rounded, size: 36, color: AppColors.textHint), const SizedBox(height: 8), Text('暫無資料', style: TextStyle(color: AppColors.textHint, fontSize: 13))]))
                  : PageView.builder(
                      controller: _restaurantPageCtrl, padEnds: false, itemCount: _restaurants.length,
                      itemBuilder: (_, i) {
                        return AnimatedBuilder(
                          animation: _restaurantPageCtrl,
                          builder: (_, child) {
                            double offset = 0;
                            if (_restaurantPageCtrl.position.haveDimensions) { offset = (_restaurantPageCtrl.page! - i).clamp(-1.0, 1.0); }
                            return Transform(alignment: Alignment.center, transform: Matrix4.identity()..setEntry(3, 2, 0.0012)..rotateY(offset * 0.15), child: Opacity(opacity: (1 - offset.abs() * 0.3).clamp(0.0, 1.0), child: child));
                          },
                          child: Padding(padding: EdgeInsets.only(left: i == 0 ? 16 : 6, right: 6, top: 4, bottom: 4), child: _restaurantCard(_restaurants[i])),
                        );
                      },
                    ),
        ),
      ],
    );
  }

  Widget _restaurantCard(_RestaurantItem r) => _FlipRestaurantCard(r: r, onShowDetail: () => _showRestaurantDetail(r));

  Widget _restaurantShimmer() => Container(width: 170, margin: const EdgeInsets.only(right: 12), decoration: BoxDecoration(color: AppColors.surfaceMoss, borderRadius: BorderRadius.circular(20)));

  void _showRestaurantDetail(_RestaurantItem r) {
    final ctx = context;
    showModalBottomSheet(
      context: ctx, isScrollControlled: true, backgroundColor: Colors.transparent,
      builder: (_) => _RestaurantDetailSheet(
        r: r, onViewOnMap: (r.lat != null && r.lng != null) ? () {
                Navigator.of(ctx).pop();
                MapScreen.focusNotifier.value = (lat: r.lat!, lng: r.lng!, catKey: MapScreen.catKeyChiayiFood);
                widget.onSwitchTab?.call(2);
              } : null,
      ),
    );
  }

  Widget _buildNearbySpots() {
    final primary = context.appPrimary;
    final filtered = _nearbyFilter == '全部' ? _nearbySpots : _nearbySpots.where((s) => s.category == _nearbyFilter).toList();
    final shown = filtered.take(6).toList();

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 0),
      child: _warmSection(
        margin: EdgeInsets.zero, padding: const EdgeInsets.fromLTRB(14, 16, 14, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(padding: const EdgeInsets.only(left: 2, bottom: 12), child: SectionHeader(title: _spotSectionTitle, actionText: '地圖', onAction: () => widget.onSwitchTab?.call(2))),
            SizedBox(
              height: 34,
              child: ListView.separated(
                scrollDirection: Axis.horizontal, itemCount: _kNearbyFilters.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (_, i) {
                  final f = _kNearbyFilters[i]; final active = f == _nearbyFilter;
                  return GestureDetector(
                    onTap: () => setState(() => _nearbyFilter = f),
                    child: AnimatedContainer(duration: const Duration(milliseconds: 180), padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6), decoration: BoxDecoration(color: active ? primary : const Color(0xFFF5F1EB), borderRadius: BorderRadius.circular(20), border: Border.all(color: active ? primary : const Color(0xFFE8E0D4))), child: Text(f, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: active ? Colors.white : AppColors.textSecondary))),
                  );
                },
              ),
            ),
            const SizedBox(height: 10),
            _nearbyLoading ? Column(children: List.generate(4, (_) => _nearbyRowShimmer())) : filtered.isEmpty ? Padding(padding: const EdgeInsets.symmetric(vertical: 20), child: Center(child: Text('此分類暫無資料', style: TextStyle(color: AppColors.textHint, fontSize: 13)))) : Column(children: shown.asMap().entries.map((e) => _nearbyRow(e.value)
              .animate(key: ValueKey('${e.value.name}_${_nearbyFilter}'))
              .fadeIn(delay: (e.key * 60).ms, duration: 280.ms)
              .slideX(begin: 0.06, end: 0, delay: (e.key * 60).ms, duration: 280.ms, curve: Curves.easeOutCubic)).toList()),
          ],
        ),
      ),
    );
  }

  static const _kCatIcon = <String, IconData>{'TDX景點': Icons.account_balance_rounded, '好店': Icons.store_rounded, '寵物友善': Icons.pets_rounded, '飲料店': Icons.local_cafe_rounded};
  static const _kCatColor = {'TDX景點': Color(0xFF6A9E70), '好店': Color(0xFFE8845A), '寵物友善': Color(0xFF6BA3C8), '飲料店': Color(0xFF9C7FC0)};

  Widget _nearbyRow(_NearbySpotItem s) {
    final primary = context.appPrimary; final catColor = _kCatColor[s.category] ?? primary;
    return TapFeedback(
      onTap: () => _showNearbySpotDetail(s),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 8, offset: const Offset(0, 2))]),
        child: Row(children: [
          Container(width: 44, height: 44, decoration: BoxDecoration(color: catColor.withValues(alpha: 0.10), borderRadius: BorderRadius.circular(14)), child: Center(child: Icon(_kCatIcon[s.category] ?? Icons.place_rounded, size: 22, color: catColor))),
          const SizedBox(width: 12),
          Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Expanded(child: Text(s.name, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary), maxLines: 1, overflow: TextOverflow.ellipsis)),
                Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2), decoration: BoxDecoration(color: catColor.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(8)), child: Text(s.category, style: TextStyle(fontSize: 9, color: catColor, fontWeight: FontWeight.w700))),
              ]),
              if (s.address.isNotEmpty) ...[
                const SizedBox(height: 4),
                Row(children: [const Icon(Icons.location_on_outlined, size: 11, color: AppColors.textHint), const SizedBox(width: 3), Expanded(child: Text(s.address, style: const TextStyle(fontSize: 11, color: AppColors.textHint), maxLines: 1, overflow: TextOverflow.ellipsis))]),
              ],
            ],
          )),
          const SizedBox(width: 6),
          // ── Save button ──────────────────────────────────────
          SpotSaveButton(
            spotId:      s.id,
            spotName:    s.name,
            imageUrl:    s.imageUrl,
            size:        15,
            description: s.description,
            address:     s.address,
            category:    s.category,
          ),
          const SizedBox(width: 4),
          const Icon(Icons.chevron_right_rounded, color: AppColors.textHint, size: 18),
        ]),
      ),
    );
  }

  Widget _nearbyRowShimmer() => Container(height: 66, margin: const EdgeInsets.only(bottom: 8), decoration: BoxDecoration(color: AppColors.surfaceMoss, borderRadius: BorderRadius.circular(14)));

  void _showNearbySpotDetail(_NearbySpotItem s) {
    final catColor = _kCatColor[s.category] ?? context.appPrimary; final hasMap = s.lat != null && s.lng != null;
    showModalBottomSheet(
      context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
      builder: (sheetCtx) => DraggableScrollableSheet(
        initialChildSize: s.description.isNotEmpty ? 0.60 : 0.48, maxChildSize: 0.92,
        builder: (_, scroll) => Container(
          decoration: const BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
          child: ListView(
            controller: scroll, padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
            children: [
              Center(child: Container(width: 36, height: 4, margin: const EdgeInsets.only(bottom: 18), decoration: BoxDecoration(color: AppColors.divider, borderRadius: BorderRadius.circular(2)))),
              Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Container(width: 54, height: 54, decoration: BoxDecoration(color: catColor.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(14)), child: Center(child: Icon(_kCatIcon[s.category] ?? Icons.place_rounded, size: 26, color: catColor))),
                const SizedBox(width: 14),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(s.name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppColors.textPrimary), maxLines: 2, overflow: TextOverflow.ellipsis), const SizedBox(height: 5), Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3), decoration: BoxDecoration(color: catColor.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(8)), child: Text(s.category, style: TextStyle(fontSize: 11, color: catColor, fontWeight: FontWeight.w700)))]))
              ]),
              if (s.address.isNotEmpty) ...[
                const SizedBox(height: 12),
                Row(children: [const Icon(Icons.location_on_outlined, size: 14, color: AppColors.textHint), const SizedBox(width: 6), Expanded(child: Text(s.address, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary, height: 1.4)))])
              ],
              if (s.description.isNotEmpty) ...[
                const Divider(height: 28), Text(context.read<AppSettingsProvider>().l10n.widgetSpotIntro, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textSecondary)),
                const SizedBox(height: 8), TranslatedText(text: s.description, style: const TextStyle(fontSize: 13, color: AppColors.textPrimary, height: 1.75), domain: TranslationDomain.spot),
              ],
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () {
                    Navigator.of(sheetCtx).pop();
                    final catKey = {'TDX景點': MapScreen.catKeyTdxSpot, '好店': MapScreen.catKeyGoodShop, '寵物友善': MapScreen.catKeyPetShop, '飲料店': MapScreen.catKeyDrinkShop}[s.category];
                    MapScreen.focusNotifier.value = (lat: hasMap ? s.lat! : 23.4780, lng: hasMap ? s.lng! : 120.4407, catKey: catKey);
                    widget.onSwitchTab?.call(2);
                  },
                  icon: const Icon(Icons.map_rounded, size: 16), label: Text(hasMap ? '在地圖上查看' : '前往地圖探索'),
                  style: ElevatedButton.styleFrom(backgroundColor: catColor, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 13), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                ),
              ),
              SpotRatingSection(placeId: 'nearby_${s.id}'),
            ],
          ),
        ),
      ),
    );
  }
}

class _FlipRestaurantCard extends StatefulWidget {
  final _RestaurantItem r; final VoidCallback onShowDetail;
  const _FlipRestaurantCard({required this.r, required this.onShowDetail});
  @override State<_FlipRestaurantCard> createState() => _FlipRestaurantCardState();
}

class _FlipRestaurantCardState extends State<_FlipRestaurantCard> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl; bool _showFront = true;
  @override void initState() { super.initState(); _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 480)); }
  @override void dispose() { _ctrl.dispose(); super.dispose(); }

  void _flip() {
    if (_ctrl.isAnimating) return;
    _ctrl.forward(from: 0).then((_) { if (mounted) { setState(() => _showFront = !_showFront); _ctrl.reset(); } });
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return AnimatedBuilder(
      animation: _ctrl, builder: (_, __) {
        final t = _ctrl.value; final inFirstHalf = t < 0.5;
        final faceAngle = inFirstHalf ? t * math.pi : (1.0 - t) * math.pi;
        final showingFront = inFirstHalf ? _showFront : !_showFront;
        return Transform(alignment: Alignment.center, transform: Matrix4.identity()..setEntry(3, 2, 0.001)..rotateY(faceAngle), child: showingFront ? _buildFront(widget.r, primary) : _buildBack(widget.r, primary));
      },
    );
  }

  Widget _buildFront(_RestaurantItem r, Color primary) {
    return GestureDetector(
      onTap: _flip,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(fit: StackFit.expand, children: [
          r.imageUrl.isNotEmpty
              ? Image.network(r.imageUrl, fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(color: AppColors.surfaceMoss,
                    child: Icon(Icons.restaurant_rounded, size: 48, color: AppColors.textHint)))
              : Container(color: AppColors.surfaceMoss,
                  child: Icon(Icons.restaurant_rounded, size: 48, color: AppColors.textHint)),
          Positioned.fill(child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter, end: Alignment.bottomCenter,
                colors: [Colors.transparent, Colors.black.withValues(alpha: 0.0),
                         Colors.black.withValues(alpha: 0.68)],
                stops: const [0.0, 0.45, 1.0],
              ),
            ),
          )),
          Positioned(top: 10, right: 10,
            child: SpotSaveButton(
              spotId: r.id, spotName: r.name, imageUrl: r.imageUrl,
              rating: r.rating,
              description: r.shortDesc,
              address: r.address,
              category: r.tags.isNotEmpty ? r.tags[0] : '餐廳',
              size: 15,
            )),
          Positioned(left: 14, right: 14, bottom: 14,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
              Text(r.name,
                style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w800,
                  shadows: [Shadow(color: Colors.black54, blurRadius: 4)]),
                maxLines: 2, overflow: TextOverflow.ellipsis),
              const SizedBox(height: 5),
              Row(children: [const Icon(Icons.star_rounded, size: 13, color: AppColors.accentStraw), const SizedBox(width: 3), Text(r.rating.toStringAsFixed(1), style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)), if (r.tags.isNotEmpty) ...[const SizedBox(width: 8), Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2), decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.22), borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.white.withValues(alpha: 0.35))), child: Text(r.tags.first, style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w600)))]])
            ]))
        ])),
    );
  }

  Widget _buildBack(_RestaurantItem r, Color primary) {
    return GestureDetector(
      onTap: _flip, child: Container(
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: primary.withValues(alpha: 0.2))), padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Expanded(child: Text(r.name, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary), maxLines: 2, overflow: TextOverflow.ellipsis)), Container(padding: const EdgeInsets.all(6), decoration: BoxDecoration(color: Color.lerp(primary, Colors.white, 0.88)!, shape: BoxShape.circle), child: Icon(Icons.flip_rounded, size: 14, color: primary))]),
          const SizedBox(height: 8), Row(children: [const Icon(Icons.star_rounded, size: 14, color: AppColors.accentStraw), const SizedBox(width: 4), Text(r.rating.toStringAsFixed(1), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13))]),
          if (r.address.isNotEmpty) ...[const SizedBox(height: 6), Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.location_on_outlined, size: 13, color: AppColors.textHint), const SizedBox(width: 4), Expanded(child: Text(r.address, style: const TextStyle(fontSize: 11, color: AppColors.textHint), maxLines: 2, overflow: TextOverflow.ellipsis))])],
          if (r.shortDesc.isNotEmpty) ...[const SizedBox(height: 6), Text(r.shortDesc, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary, height: 1.4), maxLines: 3, overflow: TextOverflow.ellipsis)],
          const Spacer(),
          SizedBox(width: double.infinity, child: ElevatedButton(onPressed: widget.onShowDetail, style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 8), backgroundColor: primary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))), child: const Text('查看詳情', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Colors.white))))
        ]),
      ),
    );
  }
}

class _RestaurantDetailSheet extends StatefulWidget {
  final _RestaurantItem r; final VoidCallback? onViewOnMap;
  const _RestaurantDetailSheet({required this.r, this.onViewOnMap});
  @override State<_RestaurantDetailSheet> createState() => _RestaurantDetailSheetState();
}

class _RestaurantDetailSheetState extends State<_RestaurantDetailSheet> {
  int _imgIndex = 0; final _pageCtrl = PageController();
  @override void dispose() { _pageCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final r = widget.r; final primary = Theme.of(context).colorScheme.primary; final hasImages = r.allImages.isNotEmpty;
    return DraggableScrollableSheet(
      initialChildSize: hasImages ? 0.75 : 0.55, maxChildSize: 0.95,
      builder: (ctx, scroll) => Container(
        decoration: const BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
        child: ListView(
          controller: scroll, padding: EdgeInsets.zero,
          children: [
            Padding(padding: const EdgeInsets.only(top: 12, bottom: 0), child: Center(child: Container(width: 36, height: 4, decoration: BoxDecoration(color: AppColors.divider, borderRadius: BorderRadius.circular(2))))),
            if (hasImages)
              Stack(children: [
                SizedBox(height: 220, child: PageView.builder(controller: _pageCtrl, itemCount: r.allImages.length, onPageChanged: (i) => setState(() => _imgIndex = i), itemBuilder: (_, i) => Image.network(r.allImages[i], fit: BoxFit.cover, width: double.infinity, errorBuilder: (_, __, ___) => Container(color: AppColors.surfaceMoss, child: const Center(child: Icon(Icons.restaurant_rounded, size: 52, color: AppColors.textHint)))))),
                if (r.allImages.length > 1) Positioned(bottom: 10, right: 0, left: 0, child: Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(r.allImages.length, (i) => AnimatedContainer(duration: const Duration(milliseconds: 200), margin: const EdgeInsets.symmetric(horizontal: 3), width: _imgIndex == i ? 18 : 6, height: 6, decoration: BoxDecoration(color: _imgIndex == i ? Colors.white : Colors.white.withValues(alpha: 0.5), borderRadius: BorderRadius.circular(3))))))
              ]),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [Expanded(child: Text(r.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.textPrimary))), Row(children: [const Icon(Icons.star_rounded, size: 18, color: AppColors.accentStraw), const SizedBox(width: 2), Text(r.rating.toStringAsFixed(1), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textSecondary))])]),
                  if (r.tags.isNotEmpty) ...[const SizedBox(height: 8), Wrap(spacing: 6, runSpacing: 6, children: r.tags.map((t) => Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: Color.lerp(primary, Colors.white, 0.85)!, borderRadius: BorderRadius.circular(20), border: Border.all(color: Color.lerp(primary, Colors.white, 0.5)!)), child: Text(t, style: TextStyle(fontSize: 11, color: primary, fontWeight: FontWeight.w600)))).toList())],
                  if (r.shortDesc.isNotEmpty) ...[const SizedBox(height: 12), Text(r.shortDesc, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary, height: 1.5))],
                  const SizedBox(height: 12),
                  if (r.address.isNotEmpty) _detailRow(Icons.location_on_outlined, r.address, primary),
                  if (r.openTime.isNotEmpty) _detailRow(Icons.access_time_outlined, r.openTime, primary),
                  if (r.price.isNotEmpty) _detailRow(Icons.monetization_on_outlined, r.price, primary),
                  if (widget.onViewOnMap != null) ...[const SizedBox(height: 4), SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: widget.onViewOnMap, icon: const Icon(Icons.map_outlined, size: 16), label: const Text('在地圖上查看'), style: OutlinedButton.styleFrom(foregroundColor: primary, side: BorderSide(color: primary), padding: const EdgeInsets.symmetric(vertical: 12), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))))), const SizedBox(height: 4)],
                  SpotRatingSection(placeId: 'restaurant_${r.id}'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _detailRow(IconData icon, String text, Color primary) => Padding(padding: const EdgeInsets.only(bottom: 8), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, size: 15, color: primary), const SizedBox(width: 8), Expanded(child: Text(text, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary, height: 1.4)))]));
}

class _JoyStrokesPainter extends CustomPainter {
  final Color color; const _JoyStrokesPainter({required this.color});
  void _drawLeaf(Canvas canvas, Paint paint, Offset center, double w, double h, double angle) {
    final path = Path()..moveTo(0, -h / 2)..cubicTo(w * 0.65, -h * 0.05, w * 0.65, h * 0.35, 0, h / 2)..cubicTo(-w * 0.65, h * 0.35, -w * 0.65, -h * 0.05, 0, -h / 2)..close();
    canvas.save(); canvas.translate(center.dx, center.dy); canvas.rotate(angle); canvas.drawPath(path, paint); canvas.restore();
  }
  @override void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = color..style = PaintingStyle.fill;
    _drawLeaf(canvas, paint, const Offset(5.5, 10.5), 4.5, 10.5, math.pi / 4 - 0.12);
    _drawLeaf(canvas, paint, const Offset(13.0, 13.5), 3.8,  9.0, math.pi / 4);
    _drawLeaf(canvas, paint, const Offset(21.0, 17.0), 3.0,  7.5, math.pi / 4 + 0.14);
  }
  @override bool shouldRepaint(covariant _JoyStrokesPainter old) => old.color != color;
}

class _StaticCircle extends StatelessWidget {
  final double size, alpha; final double? top, bottom, left, right;
  const _StaticCircle({required this.size, required this.alpha, this.top, this.bottom, this.left, this.right});
  @override Widget build(BuildContext context) => Positioned(top: top, bottom: bottom, left: left, right: right, child: Container(width: size, height: size, decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withValues(alpha: alpha))));
}

class _AnimatedCircle extends StatefulWidget {
  final double size, alpha; final Duration duration; final double scaleTo; final bool reverse; final double? top, bottom, left, right;
  const _AnimatedCircle({required this.size, required this.alpha, required this.duration, required this.scaleTo, this.reverse = false, this.top, this.bottom, this.left, this.right});
  @override State<_AnimatedCircle> createState() => _AnimatedCircleState();
}

class _AnimatedCircleState extends State<_AnimatedCircle> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl; late final Animation<double> _scaleAnim;
  @override void initState() { super.initState(); _ctrl = AnimationController(vsync: this, duration: widget.duration); _scaleAnim = Tween<double>(begin: 1.0, end: widget.scaleTo).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut)); if (widget.reverse) { _ctrl.repeat(reverse: true); _ctrl.forward(from: 0.5); } else { _ctrl.repeat(reverse: true); } }
  @override void dispose() { _ctrl.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Positioned(top: widget.top, bottom: widget.bottom, left: widget.left, right: widget.right, child: ScaleTransition(scale: _scaleAnim, child: Container(width: widget.size, height: widget.size, decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withValues(alpha: widget.alpha)))));
}

class _PulsingDot extends StatefulWidget {
  const _PulsingDot();
  @override State<_PulsingDot> createState() => _PulsingDotState();
}

class _PulsingDotState extends State<_PulsingDot> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl; late final Animation<double> _scale, _opacity;
  @override void initState() { super.initState(); _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))..repeat(reverse: true); _scale = Tween<double>(begin: 0.85, end: 1.20).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut)); _opacity = Tween<double>(begin: 1.0, end: 0.55).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut)); }
  @override void dispose() { _ctrl.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => AnimatedBuilder(animation: _ctrl, builder: (_, __) => Opacity(opacity: _opacity.value, child: Transform.scale(scale: _scale.value, child: Container(width: 10, height: 10, decoration: BoxDecoration(color: AppColors.error, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 1.5))))));
}

class _QuickItem {
  final dynamic icon; final String label; final Color color; final VoidCallback onTap;
  _QuickItem(this.icon, this.label, this.color, this.onTap);
}

class _BounceQuickButton extends StatefulWidget {
  final _QuickItem item; const _BounceQuickButton({required this.item});
  @override State<_BounceQuickButton> createState() => _BounceQuickButtonState();
}

class _BounceQuickButtonState extends State<_BounceQuickButton> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl; late final Animation<double> _scale;
  @override void initState() { super.initState(); _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 100), reverseDuration: const Duration(milliseconds: 500)); _scale = Tween<double>(begin: 1.0, end: 0.85).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeIn, reverseCurve: Curves.elasticOut)); }
  @override void dispose() { _ctrl.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _ctrl.forward(), onTapCancel: () => _ctrl.reverse(),
      onTapUp: (_) { _ctrl.reverse(); widget.item.onTap(); },
      child: AnimatedBuilder(animation: _scale, builder: (_, child) => Transform.scale(scale: _scale.value, child: child), child: StitchedBox(color: widget.item.color, stitchColor: AppColors.textHint.withValues(alpha: 0.7), radius: 16, inset: 4, dashWidth: 5, dashGap: 4, stitchStrokeWidth: 1.1, padding: const EdgeInsets.symmetric(vertical: 13), child: Column(mainAxisSize: MainAxisSize.min, children: [HugeIcon(icon: widget.item.icon, color: AppColors.textPrimary, size: 26), const SizedBox(height: 5), Text(widget.item.label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: AppColors.textPrimary))]))),
    );
  }
}

class _RestaurantItem {
  final String id, name; final double rating; final List<String> tags; final String imageUrl; final List<String> allImages; final String address, shortDesc, price, openTime; final double? lat, lng;
  const _RestaurantItem({required this.id, required this.name, required this.rating, required this.tags, required this.imageUrl, required this.allImages, required this.address, required this.shortDesc, required this.price, required this.openTime, this.lat, this.lng});
}

class _NearbySpotItem {
  final String id, name, category, address, imageUrl, description; final double? lat, lng;
  const _NearbySpotItem({required this.id, required this.name, required this.category, required this.address, required this.imageUrl, this.description = '', this.lat, this.lng});
}

class _GovItem {
  final String title, date; final String? location, summary, url, imageUrl; final bool isEvent;
  const _GovItem({required this.title, required this.date, this.location, this.summary, this.url, this.imageUrl, required this.isEvent});
}