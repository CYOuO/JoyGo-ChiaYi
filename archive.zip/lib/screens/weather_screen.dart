import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../providers/app_settings_provider.dart';
import '../services/rail_service.dart';
import '../theme/fabric_textures.dart';

// Map weather icon key → (IconData, Color)
(IconData, Color) _weatherIcon(String key) {
  switch (key) {
    case '⛈️': case 'thunderstorm':  return (Icons.bolt_rounded,        const Color(0xFFF5C542));
    case '🌧️': case 'rain':          return (Icons.grain_rounded,        const Color(0xFF8FA8B8));
    case '🌦️': case 'rain_sun':      return (Icons.grain_rounded,        const Color(0xFF6EA0B8));
    case '🌩️': case 'lightning':     return (Icons.thunderstorm_rounded, const Color(0xFFF0BA30));
    case '☁️': case 'cloudy':        return (Icons.cloud_rounded,        const Color(0xFFB0C8D8));
    case '⛅': case 'partly_cloudy': return (Icons.cloud_rounded,        const Color(0xFF7AB8CC));
    case '🌤️': case 'mostly_sunny': return (Icons.wb_sunny_rounded,     const Color(0xFFE8C46A));
    case '☀️': case 'sunny':         return (Icons.wb_sunny_rounded,     const Color(0xFFFFB300));
    case '🌫️': case 'foggy':         return (Icons.blur_on_rounded,      const Color(0xFF90A4AE));
    case '❄️': case 'snow':          return (Icons.ac_unit_rounded,      const Color(0xFF90CAF9));
    default:                          return (Icons.cloud_rounded,        const Color(0xFF7AB8CC));
  }
}

class WeatherScreen extends StatefulWidget {
  const WeatherScreen({super.key});
  @override
  State<WeatherScreen> createState() => _WeatherScreenState();
}

class _WeatherScreenState extends State<WeatherScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  static const _weekDays = ['今天','明天','週三','週四','週五','週六','週日'];

  Future<List<Map<String, dynamic>>>? _cityWeatherFuture;
  Future<List<Map<String, dynamic>>>? _countyWeatherFuture;
  Future<Map<String, dynamic>>? _extraFuture; // UV + 日出日落

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _cityWeatherFuture   = _fetchWeather('Chiayi');
    _countyWeatherFuture = _fetchWeather('ChiayiCounty');
    _extraFuture         = RailService.getWeatherExtra();
  }

  Future<List<Map<String, dynamic>>> _fetchWeather(String cityType) async {
    return await RailService.getWeather(cityType);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        title: Builder(builder: (bCtx) {
          final p = Theme.of(bCtx).colorScheme.primary;
          return Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.cloud_rounded, size: 18, color: p),
            const SizedBox(width: 6),
            Text(context.watch<AppSettingsProvider>().l10n.weatherTitle, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
            const SizedBox(width: 6),
            DoodleHeart(color: p.withValues(alpha: 0.50), size: 10),
          ]);
        }),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: '嘉義市'),
            Tab(text: '嘉義縣（阿里山）'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildWeatherTabWrapper('嘉義市', '23.4780° N, 120.4407° E', _cityWeatherFuture),
          _buildWeatherTabWrapper('嘉義縣・阿里山', '23.5083° N, 120.8034° E', _countyWeatherFuture),
        ],
      ),
    );
  }

  Widget _buildWeatherTabWrapper(String name, String coord, Future<List<Map<String, dynamic>>>? future) {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: future,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(
            child: CircularProgressIndicator(color: Theme.of(context).colorScheme.primary),
          );
        }
        if (snapshot.hasError || !snapshot.hasData || snapshot.data!.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.cloud_off_rounded, size: 48, color: AppColors.textHint),
                const SizedBox(height: 12),
                Text(context.read<AppSettingsProvider>().l10n.weatherLoadFail, style: const TextStyle(color: AppColors.textHint)),
                const SizedBox(height: 16),
                ElevatedButton.icon(
                  onPressed: () {
                    setState(() {
                      _cityWeatherFuture = _fetchWeather('Chiayi');
                      _countyWeatherFuture = _fetchWeather('ChiayiCounty');
                    });
                  },
                  icon: const Icon(Icons.refresh_rounded, size: 16),
                  label: Text(context.read<AppSettingsProvider>().l10n.weatherRefresh),
                )
              ],
            ),
          );
        }
        return _buildWeatherTab(name, coord, snapshot.data!);
      },
    );
  }

  Widget _buildWeatherTab(String name, String coord, List<Map<String, dynamic>> data, {Map<String, dynamic>? extra}) {
    final today = data[0];
    final (todayIconData, todayIconColor) = _weatherIcon(today['icon'] as String);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [const Color(0xFF7AB8CC), Theme.of(context).colorScheme.primary],
            ),
            borderRadius: BorderRadius.circular(24),
            boxShadow: [BoxShadow(color: const Color(0xFF7AB8CC).withOpacity(0.25), blurRadius: 16, offset: const Offset(0, 6))],
          ),
          child: Column(
            children: [
              Row(children: [
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(name, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700)),
                  Text(coord, style: TextStyle(color: Colors.white.withOpacity(0.75), fontSize: 10)),
                  const SizedBox(height: 4),
                  Text('今天 · ${today['desc']}', style: TextStyle(color: Colors.white.withOpacity(0.85), fontSize: 13)),
                ]),
                const Spacer(),
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Icon(todayIconData, size: 52, color: todayIconColor.withOpacity(0.92)),
                  Row(children: [
                    Text('${today['high']}°', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 18)),
                    Text(' / ${today['low']}°', style: TextStyle(color: Colors.white.withOpacity(0.75), fontSize: 14)),
                  ]),
                ]),
              ]),
              const SizedBox(height: 18),
              Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                _todayDetail(Icons.umbrella_rounded,    '降雨機率', '${today['rain']}%',   iconColor: const Color(0xFF80CFEE)),
                _todayDetail(Icons.water_drop_rounded,  '相對濕度', '${today['humid']}%',  iconColor: const Color(0xFF90DDEE)),
                _todayDetail(Icons.air_rounded,         '風速',    '${today['wind']}km/h', iconColor: const Color(0xFFB0E8D8)),
                _todayDetail(Icons.thermostat_rounded,  '體感',    '${(today['high'] as int) + 2}°C', iconColor: const Color(0xFFFFD580)),
              ]),
            ],
          ),
        ),
        const SizedBox(height: 16),
        // ── 7-day forecast ──
        StitchedBox(
          color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.05),
          stitchColor: Theme.of(context).colorScheme.primary.withValues(alpha: 0.22),
          radius: 20, inset: 4, dashWidth: 4, dashGap: 3,
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Icon(Icons.calendar_today_rounded, size: 15, color: Theme.of(context).colorScheme.primary),
                const SizedBox(width: 6),
                Text(context.read<AppSettingsProvider>().l10n.weather7Day, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14, color: AppColors.textPrimary)),
              ]),
              const SizedBox(height: 14),
              ...data.asMap().entries.map((e) => _forecastRow(e.key, e.value)),
            ],
          ),
        ),
        const SizedBox(height: 16),
        FutureBuilder<Map<String, dynamic>>(
          future: _extraFuture,
          builder: (ctx, snap) {
            final e = snap.data ?? {};
            final hasData = e.isNotEmpty;
            return Column(children: [
              Row(children: [
                Expanded(child: _infoCard(Icons.wb_sunny_rounded, 'UV 指數',
                    hasData ? (e['uviLabel'] as String) : '--',
                    hasData ? (e['uviTip'] as String) : '資料暫時無法取得',
                    AppColors.accentTerra)),
                const SizedBox(width: 12),
                Expanded(child: _infoCard(Icons.sentiment_satisfied_rounded, '舒適度',
                    hasData ? (e['comfort'] as String) : '--',
                    hasData ? (e['comfortTip'] as String) : '---',
                    AppColors.accentSky)),
              ]),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: _infoCard(Icons.wb_twilight_rounded, '日出日落',
                    hasData ? '${e['sunrise']} / ${e['sunset']}' : '--:-- / --:--',
                    hasData ? '日照時間 ${e['daylightH']} 小時' : '---',
                    AppColors.accentStraw)),
                const SizedBox(width: 12),
                Expanded(child: _infoCard(Icons.waves_rounded, '天氣警報', '無', '目前無特殊天氣警報',
                    Theme.of(context).colorScheme.primary)),
              ]),
            ]);
          },
        ),
        const SizedBox(height: 40),
      ],
    );
  }

  Widget _todayDetail(IconData icon, String label, String val, {Color? iconColor}) {
    return Column(children: [
      Icon(icon, size: 18, color: iconColor ?? Colors.white.withOpacity(0.9)),
      const SizedBox(height: 3),
      Text(val, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 14)),
      Text(label, style: TextStyle(color: Colors.white.withOpacity(0.75), fontSize: 9)),
    ]);
  }

  Widget _forecastRow(int i, Map<String, dynamic> d) {
    final high = d['high'] as int;
    final low = d['low'] as int;
    final rain = d['rain'] as int;
    final isToday = i == 0;
    final (iconData, iconColor) = _weatherIcon(d['icon'] as String);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(children: [
        SizedBox(width: 34,
          child: Text(
            i < _weekDays.length ? _weekDays[i] : '第 ${i+1} 天',
            style: TextStyle(
              fontWeight: isToday ? FontWeight.w800 : FontWeight.w500,
              fontSize: 13,
              color: isToday ? Theme.of(context).colorScheme.primary : AppColors.textSecondary,
            ))),
        const SizedBox(width: 10),
        Icon(iconData, size: 20, color: iconColor),
        const SizedBox(width: 8),
        Expanded(child: Text(d['desc'] as String,
          style: const TextStyle(fontSize: 12, color: AppColors.textHint))),
        SizedBox(width: 36, child: Column(children: [
          Text('$rain%', style: TextStyle(fontSize: 10,
            color: rain > 50 ? AppColors.accentSky : AppColors.textHint)),
          const SizedBox(height: 2),
          ClipRRect(borderRadius: BorderRadius.circular(2),
            child: LinearProgressIndicator(value: rain/100, minHeight: 3,
              backgroundColor: AppColors.divider,
              valueColor: AlwaysStoppedAnimation<Color>(rain > 50 ? AppColors.accentSky : AppColors.divider))),
        ])),
        const SizedBox(width: 10),
        Text('$low°', style: const TextStyle(fontSize: 13, color: AppColors.textHint, fontWeight: FontWeight.w600)),
        const Padding(padding: EdgeInsets.symmetric(horizontal: 4), child: Text('—', style: TextStyle(color: AppColors.divider))),
        Text('$high°', style: const TextStyle(fontSize: 13, color: AppColors.textPrimary, fontWeight: FontWeight.w800)),
      ]),
    );
  }

  Widget _infoCard(IconData icon, String label, String val, String sub, Color color) {
    return StitchedBox(
      color: color.withValues(alpha: 0.08),
      stitchColor: color.withValues(alpha: 0.28),
      radius: 16, inset: 4, dashWidth: 4, dashGap: 3,
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(width: 6),
          Text(label, style: TextStyle(fontSize: 11, color: color, fontWeight: FontWeight.w700)),
        ]),
        const SizedBox(height: 6),
        Text(val, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15, color: AppColors.textPrimary)),
        const SizedBox(height: 3),
        Text(sub, style: const TextStyle(fontSize: 10, color: AppColors.textHint, height: 1.3)),
      ]),
    );
  }
}